This contains all the scource code used for the game

To compile:
-sfml(2.4.2) is required and needs to be downloaded, included into the project
-a IDE or compiler that supports c++11