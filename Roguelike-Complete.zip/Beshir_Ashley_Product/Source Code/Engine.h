#ifndef _ENGINE_
#define _ENGINE_

#pragma once

#include <SFML\Graphics.hpp>
#include <vector>
#include "GameState.h"
#include <map>
#include "GUI.h"
#include "AssetsManager.h"

class GameState;

class Engine
{
public:
	
	sf::RenderWindow window;
	GUI* gui;
	sf::View guiview{ sf::Vector2f(960, 540), sf::Vector2f(1920, 1080) };
	
	void Start();
	void Delete();

	void ChangeState(GameState* state); // Deletes current state and adds new state
	void PushState(GameState* state); // Freezes current state and adds new state
	void PopState(); // Removes top stack and continues bottom onw



	void Run();
	void Input();
	void Draw();

	bool Running() { return running; }
	void Quit() { running = false; }

	Engine();
	~Engine();
private:
	std::vector<GameState*> states;
	bool running;
};


#endif // !_ENGINE_


