#ifndef _WIDGET_
#define _WIDGET_
#pragma once
#include "GUI.h"
#include <SFML\Graphics.hpp>

#define Button_X 130
#define Button_Y 30

enum class GUITYPE
{
	button,
	label,
	console,
	list,
	input
};

struct Widget : public sf::Drawable
{
	GUITYPE type;
	
	virtual bool check(int x, int y) { return false; }//Check to see if mouse position is on widget
	virtual bool clicked(int x, int y) { return false; } //Returns a boolean from sent mouse coordinates
	virtual sf::String const& GetString() { return ""; }
};


#endif // !_WIDGET_



