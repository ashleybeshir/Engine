The game was made and tested on a 1920 x 1080 resolution so set resolution to that before testing.
GUI bugs might happen at different resolutions.

Entity.xml can be used to add/remove/edit monster ingame
item.xml can be used to add/remove/edit items ingame